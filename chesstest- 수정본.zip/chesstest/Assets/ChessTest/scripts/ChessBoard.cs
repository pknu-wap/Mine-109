﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace ChessTest {
    public class ChessBoard : MonoBehaviour {
        public List<ChessPiece> pieces;
        public ChessPiece prefab;
        public Material white, black;
        public int size;
        int getIndex(int x, int z) {
            return size * x + z;
        }
        public void Start() {
            pieces = new List<ChessPiece>();
            ChessPiece t;

            for (int i = 0; i < size; i++) {
                for (int j = 0; j < size; j++) {
                    bool isWhite = (i + j) % 2 == 0;
                    t = Instantiate(prefab, transform);
                    t.X = i;
                    t.Z = j;
                    t.isWhite = isWhite;
                    t.GetComponent<MeshRenderer>().material.color = isWhite ? Color.white : Color.black;
                    t.transform.position = new Vector3(t.X, -.5f, t.Z);
                    pieces.Add(t);
                }

            }
        }
    }
}
