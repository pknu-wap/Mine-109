﻿using UnityEngine;
using System.Collections;
namespace ChessTest {
    public class ChessPiece : MonoBehaviour {
        public bool isWhite;
        public int X, Z;
    }
}