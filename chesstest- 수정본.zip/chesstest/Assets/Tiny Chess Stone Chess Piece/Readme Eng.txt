Content:

1) Chess piece

�� - 6 white and 6 black ,stylized as a stone, chess pieces with 1k textures. + normal maps

��Polygon: from 80 to 280 triangles on a chess piece

2) Environment

���- stylized as a stone, a chess battlefield with 1k textures. + normal maps

�Polygon: 2,4 k tris

3) Png Icon for chess piece

All scene with 32 chess pieces and environment,using baking light - 10k triangles

Size: 125mb - textures, 3mb - other

ATTENTION! To display some elements (flags), you need a two-sided shader

   I used the free Double Sided Shaders by CICONIA STUDIO.
�  Link: https://assetstore.unity.com/packages/vfx/shaders/double-sided-shaders-23087

If you have any questions / suggestions / comments, etc., I will be happy to listen to you and try to help you!
My email: 3boxassets@gmail.com
Twitter:https://twitter.com/KliutkoCS

Thank you!
